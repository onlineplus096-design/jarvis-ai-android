package com.example.jarvisai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.util.TypedValue
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 48, 32, 48)
            setBackgroundColor(Color.rgb(10, 14, 25))
        }
        val title = TextView(this).apply {
            text = "JARVIS AI"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "আমি প্রস্তুত। মাইক্রোফোন বাটনে চাপ দিয়ে কথা বলুন।"
            setTextColor(Color.LTGRAY)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 32)
        }
        val listen = Button(this).apply {
            text = "🎙 কথা বলুন"
            setOnClickListener { listenOnce() }
        }
        val note = TextView(this).apply {
            text = "প্রাথমিক সংস্করণ: অ্যাপ খোলা ও সাধারণ ভয়েস কমান্ড। সবসময় শোনার Wake Word এখনো যুক্ত হয়নি।"
            setTextColor(Color.GRAY)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(listen)
        layout.addView(note)
        setContentView(layout)
    }

    private fun listenOnce() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "এই ফোনে Speech Recognition পাওয়া যাচ্ছে না।"
            speak("এই ফোনে ভয়েস শনাক্ত করার সুবিধা পাওয়া যাচ্ছে না।")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "বলুন, কী করতে হবে?")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        status.text = "শুনছি..."
        recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "বলুন..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "আপনার কথা বুঝছি..." }
            override fun onError(error: Int) {
                status.text = "শোনা যায়নি। আবার চেষ্টা করুন। (কোড: $error)"
            }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val command = words?.firstOrNull().orEmpty()
                status.text = "আপনি বলেছেন: $command"
                handleCommand(command)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer?.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val c = raw.lowercase(Locale.ROOT)
        when {
            c.contains("youtube") || c.contains("ইউটিউব") -> openApp("com.google.android.youtube", "YouTube খুলছি।")
            c.contains("facebook") || c.contains("ফেসবুক") -> openApp("com.facebook.katana", "Facebook খুলছি।")
            c.contains("chrome") || c.contains("ক্রোম") || c.contains("গুগল") -> openApp("com.android.chrome", "Chrome খুলছি।")
            c.contains("whatsapp") || c.contains("হোয়াটসঅ্যাপ") || c.contains("হোয়াটসঅ্যাপ") ->
                openApp("com.whatsapp", "WhatsApp খুলছি।")
            c.contains("সময়") || c.contains("time") -> {
                val now = java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())
                status.text = "এখন সময় $now"
                speak("এখন সময় $now")
            }
            else -> {
                status.text = "কমান্ডটি এখনো শিখিনি: $raw"
                speak("দুঃখিত, এই কাজটি এখনো করতে শিখিনি।")
            }
        }
    }

    private fun openApp(packageName: String, message: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            speak(message)
            startActivity(launch)
        } else {
            status.text = "এই অ্যাপটি ফোনে ইনস্টল করা নেই।"
            speak("এই অ্যাপটি ফোনে ইনস্টল করা নেই।")
        }
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("bn", "BD"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale("en", "US")
            }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
