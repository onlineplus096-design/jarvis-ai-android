# JARVIS AI — Starter Android App

Starter build for Android 8.0+ (min SDK 26), configured for Android 15.

## What this first build does
- Shows a simple JARVIS dashboard.
- Uses Android speech recognition after you tap the microphone button.
- Understands a small set of Bengali/English app-opening commands:
  YouTube, Facebook, Chrome, WhatsApp.
- Speaks a basic Bengali response using Android Text-to-Speech.

## Important limitations
- This is a starter prototype, not a full AI agent.
- It does not yet include the always-listening "Hey My Phone" wake word.
- It does not yet control other apps' screens, send messages, or perform multi-step actions.
- Speech recognition availability/language support depends on Android speech services installed on the phone.
- Do not grant permissions to unknown apps or share account passwords/OTP codes.

## Build APK with GitHub Actions
1. Upload all files and folders in this project to the root of your GitHub repository.
2. Open the repository's **Actions** tab.
3. If prompted, allow GitHub Actions.
4. Choose **Build JARVIS APK** and tap **Run workflow** (or wait for the push build).
5. Open the completed workflow run.
6. Under **Artifacts**, download `JARVIS-AI-debug-APK`.
7. Extract the ZIP and install `app-debug.apk` on your Samsung phone. Android may ask you to allow installation from your browser/files app.

For a production release, the app must be signed with a private signing key. Keep that key private.
